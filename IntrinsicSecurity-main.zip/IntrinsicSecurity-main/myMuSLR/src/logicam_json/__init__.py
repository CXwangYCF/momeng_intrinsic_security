"""JSON-constrained LogiCAM experiment."""
