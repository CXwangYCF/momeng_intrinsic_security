"""Result visualization dashboard."""
